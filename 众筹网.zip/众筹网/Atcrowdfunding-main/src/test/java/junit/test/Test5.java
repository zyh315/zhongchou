package junit.test;

import java.util.Date;

public class Test5 {

	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		
		
		int s = 100000 ;
		int t = 10 ;
		
		for (int i = 0; i < s; i++) {
			Date date = new Date();
			System.out.println("iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii="+i + "-----"+date);
			for (int j = 0; j < t; j++) {
				Date date2 = new Date();
				System.out.println("jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj="+j +"-----"+date2 );
			}
		}

		long end = System.currentTimeMillis();
		
		System.out.println("start"+start);
		System.out.println("end"+end);
		
		System.out.println("end-start="+(end-start));
	}

}
