package junit.test;

public class Test02 {

	public static void main(String[] args) {
		byte b = 10;
		test(b);
	}
	  
	public static void test(byte b) {
		System.out.println("bbbb");
	}
	 
	public static void test(short s) { 
		System.out.println("ssss");
	}

	public static void test(char c) { 
		System.out.println("ccccc");
	}
	 
	public static void test(int i) { 
		System.out.println("iiiiii");
	}

}
