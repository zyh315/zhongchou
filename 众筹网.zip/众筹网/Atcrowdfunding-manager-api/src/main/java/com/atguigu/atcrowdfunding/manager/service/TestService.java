package com.atguigu.atcrowdfunding.manager.service;

public interface TestService {

	public void insert();
	
}
